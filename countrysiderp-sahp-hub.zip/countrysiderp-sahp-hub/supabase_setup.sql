-- Run in Supabase SQL Editor. All data is managed through the server-side admin panel.
create extension if not exists pgcrypto;
create table if not exists public.personnel (id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(), name text not null default '', callsign text default '', rank text default 'Probationary Trooper', division text default '', discord_id text default '', status text default 'Active');
create table if not exists public.announcements (id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(), title text not null default '', body text default '');
create table if not exists public.promotions (id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(), name text default '', old_rank text default '', new_rank text default '', note text default '');
create table if not exists public.vehicles (id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(), name text default '', authorized_ranks text default '', notes text default '', image_url text default '');
create table if not exists public.uniforms (id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(), name text default '', authorized_ranks text default '', notes text default '', image_url text default '');
create table if not exists public.pages (id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(), slug text unique not null, title text default '', body text default '');
alter table public.personnel enable row level security;
alter table public.announcements enable row level security;
alter table public.promotions enable row level security;
alter table public.vehicles enable row level security;
alter table public.uniforms enable row level security;
alter table public.pages enable row level security;
-- No anon policies: only the server-side service role key can read/write.
insert into public.pages(slug,title,body) values ('about','About SAHP','Welcome to the CountrysideRP Nevada DPS SAHP Department. Command staff can edit this page.'),('ranks','Rank Structure','Probationary Trooper\nTrooper\n\nCommand staff: Edit this structure to match your department.') on conflict(slug) do nothing;
