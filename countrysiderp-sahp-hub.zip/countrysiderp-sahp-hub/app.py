import os, secrets
from functools import wraps
from flask import Flask, render_template, request, redirect, session, flash, jsonify
import requests

app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY',secrets.token_hex(32))
URL=os.environ.get('SUPABASE_URL','').rstrip('/')
KEY=os.environ.get('SUPABASE_SERVICE_ROLE_KEY','')
ADMIN_PASSWORD=os.environ.get('ADMIN_PASSWORD','')
TABLES={'personnel','announcements','promotions','vehicles','uniforms','pages'}
FIELDS={
'personnel':['name','callsign','rank','division','discord_id','status'],
'announcements':['title','body'],
'promotions':['name','old_rank','new_rank','note'],
'vehicles':['name','authorized_ranks','notes','image_url'],
'uniforms':['name','authorized_ranks','notes','image_url'],
'pages':['slug','title','body']}
LABELS={'personnel':'Personnel Roster','announcements':'Announcements','promotions':'Promotions','vehicles':'Vehicle Structure','uniforms':'Uniform Structure','pages':'Department Pages'}

def api(table,method='GET',params=None,data=None):
    if not URL or not KEY:return [] if method=='GET' else None
    headers={'apikey':KEY,'Authorization':f'Bearer {KEY}','Content-Type':'application/json','Prefer':'return=representation'}
    r=requests.request(method,f'{URL}/rest/v1/{table}',headers=headers,params=params,json=data,timeout=15)
    r.raise_for_status()
    return r.json() if r.content else None

def rows(table):
    try:return api(table,params={'select':'*','order':'created_at.desc'})
    except Exception:return []

def protected(fn):
    @wraps(fn)
    def inner(*a,**kw):
        if not session.get('admin'):return redirect('/login')
        return fn(*a,**kw)
    return inner

@app.route('/')
def home():return render_template('home.html',announcements=rows('announcements')[:4],promotions=rows('promotions')[:5],personnel=rows('personnel'),page='home')
@app.route('/<section>')
def public(section):
    if section not in ('personnel','vehicles','uniforms','about','ranks'):return 'Not found',404
    data=rows(section) if section in TABLES else []
    page_data=next((x for x in rows('pages') if x.get('slug')==section),None)
    return render_template('public.html',section=section,data=data,page_data=page_data,page=section)
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        if ADMIN_PASSWORD and secrets.compare_digest(request.form.get('password',''),ADMIN_PASSWORD):
            session.clear();session['admin']=True;return redirect('/admin')
        flash('Incorrect password.')
    return render_template('login.html',page='login')
@app.route('/logout')
def logout():session.clear();return redirect('/')
@app.route('/admin')
@protected
def admin():return render_template('admin.html',labels=LABELS,page='admin',counts={k:len(rows(k)) for k in TABLES})
@app.route('/admin/<table>',methods=['GET','POST'])
@protected
def edit_table(table):
    if table not in TABLES:return 'Not found',404
    if request.method=='POST':
        action=request.form.get('action','add')
        try:
            if action=='delete':
                api(table,'DELETE',{'id':f'eq.{request.form.get("id", "")}'})
            else:
                data={f:request.form.get(f,'').strip() for f in FIELDS[table]}
                if action=='update':api(table,'PATCH',{'id':f'eq.{request.form.get("id", "")}'},data)
                else:api(table,'POST',data=data)
            flash('Changes saved.')
        except Exception as exc:flash('Could not save. Check Supabase configuration and database tables.')
        return redirect('/admin/'+table)
    return render_template('edit.html',table=table,label=LABELS[table],fields=FIELDS[table],items=rows(table),page='admin')

if __name__=='__main__':app.run(debug=False)
