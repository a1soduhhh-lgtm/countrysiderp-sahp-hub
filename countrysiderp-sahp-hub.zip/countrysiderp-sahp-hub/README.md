# CountrysideRP Nevada DPS SAHP Hub

Public department website with private command administration. Flask + Supabase + Render.

## Setup
1. Create a Supabase project at https://supabase.com/dashboard.
2. In SQL Editor, paste and run `supabase_setup.sql`.
3. In Supabase Project Settings / API, find the Project URL and the `service_role` secret key. NEVER place the secret key in GitHub or frontend code.
4. Upload this project's files to a **private GitHub repository** (do not upload a `.env` file).
5. On Render, create a new **Web Service** connected to the repository, choose Python, Free instance (if offered), Build Command `pip install -r requirements.txt`, Start Command `gunicorn app:app`.
6. In Render Environment, set `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_PASSWORD` (a strong unique password), and `SECRET_KEY` (long random string). Deploy.
7. Visit `https://YOUR-SERVICE.onrender.com/admin`, log in, and add records.

## Important
- Do not publish real private member details: public roster is visible to everyone. Discord IDs are stored but not displayed publicly.
- Use a strong admin password. This starter supports one shared command password, not individual staff accounts. For larger communities, add individual authentication, roles, MFA, rate limiting and audit logging before broad command access.
- Render free services may sleep when idle. Supabase free projects may pause due to inactivity and have usage limits; check provider terms.
- Keep the Supabase service role key private. Do not enable anonymous read/write policies.
